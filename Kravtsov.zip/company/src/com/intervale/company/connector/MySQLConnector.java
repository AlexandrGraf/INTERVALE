package com.intervale.company.connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//@uthor Kravtsov A

public class MySQLConnector {

    public static Connection getConnection() {
        ConnectionProperty cp = new PropertyReader().getProperty();
        Connection connection;
        try {
            Class.forName(cp.getDriver());
            try {
                String url = "jdbc:mysql://" +
                        cp.getHost() +
                        ":" +
                        cp.getPort() +
                        "/" +
                        cp.getDatabase() +
                        // не использовать SSL
                        // создание базы данных, если нет
                        // установка правил соединения и подачи информации в кодировке utf-8
                        // автопереподключение при обрыве
                        "?useSSL=false" +
                        "&createDatabaseIfNotExist=true" +
                        "&useUnicode=true" +
                        "&characterEncoding=utf-8" +
                        "&characterSetResults=utf-8" +
                        "&autoReconnect=true";
                connection = DriverManager.getConnection(
                        url,
                        cp.getUsername(),
                        cp.getPassword());
                return connection;

            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}