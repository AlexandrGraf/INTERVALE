package com.intervale.company.connector;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//@uthor Kravtsov A

public class PropertyReader {

    private final String CONNECTION_FILE_PATH = "./src/com/intervale/company/files/properties/connection.txt";

    public ConnectionProperty getProperty() {
        Map<String, String> properties = getPropertiesMap();
        ConnectionProperty cp = new ConnectionProperty();
        cp.setDriver(properties.get("driver"));
        cp.setHost(properties.get("host"));
        cp.setPort(properties.get("port"));
        cp.setDatabase(properties.get("database"));
        cp.setUsername(properties.get("username"));
        cp.setPassword(properties.get("password"));
        return cp;
    }

    private Map<String, String> getPropertiesMap() {
        List<String> lines = getPropertiesLines();
        Map<String, String> propertiesMap = new HashMap<>();
        for (String line : lines) {
            String[] array = line.split(":");
            propertiesMap.put(array[0].trim(), array[1].trim());
        }
        return propertiesMap;
    }

    private List<String> getPropertiesLines() {
        try {
            return Files.readAllLines(Paths.get(CONNECTION_FILE_PATH));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}