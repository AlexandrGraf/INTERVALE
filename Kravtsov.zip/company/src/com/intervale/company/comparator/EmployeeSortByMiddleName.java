package com.intervale.company.comparator;

import com.intervale.company.model.Employee;

import java.util.Comparator;

//@uthor Kravtsov A

public class EmployeeSortByMiddleName implements Comparator<Employee> {

    @Override
    public int compare(Employee employee1, Employee employee2) {
        return employee1.getMiddleName().compareTo(employee2.getMiddleName());
    }
}
