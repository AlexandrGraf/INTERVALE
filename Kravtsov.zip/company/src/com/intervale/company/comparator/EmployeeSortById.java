package com.intervale.company.comparator;

import com.intervale.company.model.Employee;

import java.util.Comparator;

//@uthor Kravtsov A

public class EmployeeSortById implements Comparator<Employee> {

    @Override
    public int compare(Employee employee1, Employee employee2) {
        return employee1.getId() - employee2.getId();
    }
}
