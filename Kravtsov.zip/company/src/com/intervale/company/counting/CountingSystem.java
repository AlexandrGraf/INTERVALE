package com.intervale.company.counting;

import com.intervale.company.comparator.EmployeeSortByFirstName;
import com.intervale.company.comparator.EmployeeSortByHireDate;
import com.intervale.company.comparator.EmployeeSortByLastName;
import com.intervale.company.comparator.EmployeeSortByMiddleName;
import com.intervale.company.model.Employee;
import com.intervale.company.model.Position;
import com.intervale.company.model.impl.Administration;
import com.intervale.company.query.MySQLQuery;
import com.intervale.company.query.tools.DBPreparator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.util.Collections;
import java.util.List;

//@uthor Kravtsov A

public class CountingSystem {

    private BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));

    public void getMainMenu(Connection connection) {

//        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            String item;
            try {
                menu1();
                item = bf.readLine();

                if (checkDigit(item)) {

                    switch (item) {
                        case "0":
                            System.exit(0);
                            break;
                        case "1":
                            break;
                        case "2":
                            DBPreparator.createDatabase(connection);
                            break;
                        case "3":
                            DBPreparator.createSandbox(connection);
                            break;
                    }

                    step2(connection);

                } else {
                    System.out.println("Введите число");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void menu1() {
        System.out.println("Menu level 1\n" +
                "1 - Начать работу с программой\n" +
                "2 - Создать базу данных\n" +
                "3 - Создать песочницу\n" +
                "0 - Выход");
    }

    private void menu2() {
        System.out.println("Menu level 2\n" +
                "1 - Просмотреть всех\n" +
                "2 - Добавить нового\n" +
                "3 - Переместить\n" +
                "4 - Удалить\n" +
                "0 - Выход");
    }

    private void menu21() {
        System.out.println("Menu level 2-1\n" +
                "1 - Вывод как есть\n" +
                "2 - Сортировка по ФИО\n" +
                "3 - Сортировка по дате найма\n" +
                "4 - Сортировка по ФИО + дате найма\n" +
                "0 - Выход");
    }

    private void menu22() {
        System.out.println("Menu level 2-2\n" +
                "1 - Администрация\n" +
                "2 - Менеджер\n" +
                "3 - Работник\n" +
                "0 - Выход");
    }

    private void step2(Connection connection) {
//        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String item;
        try {
            while (true) {
                menu2();
                item = bf.readLine();
                if (item.equals("0")) {
                    break;
                } else {
                    if (checkDigit(item)) {
                        switch (item) {
                            case "1":
                                step3(connection);
                                break;
                            case "2":
                                step4(connection);
                                break;
                            case "3":
                                break;
                            case "4":
                                break;
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void step3(Connection connection) {
//        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String item;
        MySQLQuery mySQLQuery = new MySQLQuery();
        List<Employee> list = mySQLQuery.getAll(connection);
        menu21();
        try {
            item = bf.readLine();
            if (checkDigit(item)) {
                switch (item) {
                    case "1":
                        System.out.println("--------------------------------------------------------");
                        list = mySQLQuery.getAll(connection);
                        for (Employee employee : list) {
                            System.out.println(employee);
                        }
                        System.out.println("--------------------------------------------------------");
                        break;
                    case "2":
                        System.out.println("--------------------------------------------------------");
                        Collections.sort(list,
                                new EmployeeSortByLastName()
                                        .thenComparing(new EmployeeSortByFirstName()
                                        .thenComparing(new EmployeeSortByMiddleName())));
                        for (Employee employee : list) {
                            System.out.println(employee);
                        }
                        System.out.println("--------------------------------------------------------");
                        break;
                    case "3":
                        System.out.println("--------------------------------------------------------");
                        Collections.sort(list, new EmployeeSortByHireDate());
                        for (Employee employee : list) {
                            System.out.println(employee);
                        }
                        System.out.println("--------------------------------------------------------");
                        break;
                    case "4":
                        System.out.println("--------------------------------------------------------");
                        Collections.sort(list,
                                new EmployeeSortByLastName()
                                        .thenComparing(new EmployeeSortByFirstName()
                                        .thenComparing(new EmployeeSortByMiddleName()
                                        .thenComparing(new EmployeeSortByHireDate()))));
                        for (Employee employee : list) {
                            System.out.println(employee);
                        }
                        System.out.println("--------------------------------------------------------");
                        break;
                }
            } else {
                System.out.println("Введите число");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void step4(Connection connection) {
        String item;
        MySQLQuery mySQLQuery = new MySQLQuery();
        try {
            while (true) {
                menu22();
                item = bf.readLine();

                if (item.equals("0")) {
                    break;
                }

                if (checkDigit(item)) {

                    Administration administration = new Administration();

                    Position position = mySQLQuery.getPosition(connection, Integer.parseInt(item));
                    administration.setPosition(position);

                    System.out.println("Position id = " + position.getId());

                    System.out.print("Имя: ");
                    String firstName = bf.readLine();
                    administration.setFirstName(firstName);

                    System.out.print("Фамилия: ");
                    String lastName = bf.readLine();
                    administration.setLastName(lastName);

                    System.out.print("Отчество: ");
                    String middleName = bf.readLine();
                    administration.setMiddleName(middleName);

                    System.out.print("Дата рождения: ");
                    String birthDate = bf.readLine();
                    administration.setBirthDate(Date.valueOf(birthDate));

                    System.out.print("Дата приема: ");
                    String hireDate = bf.readLine();
                    administration.setHireDate(Date.valueOf(hireDate));

                    if (Integer.parseInt(item) == 1) {
                        System.out.print("Описание: ");
                        String description = bf.readLine();
                        administration.setDescription(description);
                    } else {
                        administration.setDescription("");
                    }

                    if (administration != null) {
                        mySQLQuery.addOne(connection, administration);
                    } else {
                        System.out.println("Заполните все поля");
                    }

                } else {
                    System.out.println("Введите число");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createEmployee(Connection connection, Administration administration) {
        MySQLQuery mySQLQuery = new MySQLQuery();
    }

    private boolean checkDigit(String line) {
        try {
            int item = Integer.parseInt(line);
            return true;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return false;
        }
    }
}
