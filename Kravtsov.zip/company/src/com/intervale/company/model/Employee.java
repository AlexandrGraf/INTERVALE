package com.intervale.company.model;

import java.sql.Date;

//@uthor Kravtsov A

public abstract class Employee {

    private int id;
    private Position position;
    private String firstName;
    private String lastName;
    private String middleName;
    private Date birthDate;
    private Date hireDate;

    public Employee() {
    }

    public Employee(Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.birthDate = birthDate;
        this.hireDate = hireDate;
    }

    public Employee(int id, Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.birthDate = birthDate;
        this.hireDate = hireDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    @Override
    public String toString() {
        return id + "\t" +
                position.getPosition() + " " +
                firstName + " " +
                lastName + " " +
                middleName + " " +
                birthDate + " " +
                hireDate;
    }
}
