package com.intervale.company.model.impl;

import com.intervale.company.model.Employee;
import com.intervale.company.model.Position;

import java.sql.Date;
import java.util.List;

//@uthor Kravtsov A

public class Manager extends Employee {

    private List<Worker> workers;

    public Manager() {
    }

    public Manager(Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate, List<Worker> workers) {
        super(position, firstName, lastName, middleName, birthDate, hireDate);
        this.workers = workers;
    }

    public Manager(int id, Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate, List<Worker> workers) {
        super(id, position, firstName, lastName, middleName, birthDate, hireDate);
        this.workers = workers;
    }

    public List<Worker> getWorkers() {
        return workers;
    }

    public void setWorkers(List<Worker> workers) {
        this.workers = workers;
    }

    @Override
    public String toString() {
        StringBuilder workersString = new StringBuilder();
        for (Worker worker : workers) {
            workersString.append(" " + worker + "\n");
        }
        return super.toString() + "\n" + workersString.toString();
    }
}
