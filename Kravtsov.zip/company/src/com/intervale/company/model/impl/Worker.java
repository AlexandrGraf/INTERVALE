package com.intervale.company.model.impl;

import com.intervale.company.model.Employee;
import com.intervale.company.model.Position;

import java.sql.Date;

//@uthor Kravtsov A

public class Worker extends Employee {

    public Worker() {
    }

    public Worker(Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate) {
        super(position, firstName, lastName, middleName, birthDate, hireDate);
    }

    public Worker(int id, Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate) {
        super(id, position, firstName, lastName, middleName, birthDate, hireDate);
    }
}
