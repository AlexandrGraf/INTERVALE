package com.intervale.company.model.impl;

import com.intervale.company.model.Employee;
import com.intervale.company.model.Position;

import java.sql.Date;

//@uthor Kravtsov A

public class Administration extends Employee {

    private String description;

    public Administration() {
    }

    public Administration(Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate, String description) {
        super(position, firstName, lastName, middleName, birthDate, hireDate);
        this.description = description;
    }

    public Administration(int id, Position position, String firstName, String lastName, String middleName, Date birthDate, Date hireDate, String description) {
        super(id, position, firstName, lastName, middleName, birthDate, hireDate);
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return super.toString() + " " + (description == null ? "" : description);
    }
}
