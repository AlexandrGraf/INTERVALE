DROP DATABASE IF EXISTS `company`;
CREATE DATABASE IF NOT EXISTS `company` CHARACTER SET utf8 COLLATE utf8_general_ci;

SET foreign_key_checks = 0;

SET NAMES utf8;

USE `company`;

CREATE TABLE `employee` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`position` int(11) NOT NULL,
`first_name` varchar(100) NOT NULL DEFAULT '',
`last_name` varchar(100) NOT NULL DEFAULT '',
`middle_name` varchar(100) CHARACTER SET utf16 NOT NULL DEFAULT '',
`birth_date` date NOT NULL,
`hire_date` date NOT NULL,
`description` varchar(100) NOT NULL DEFAULT '',
PRIMARY KEY (`id`),
KEY `position` (`position`),
CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`position`) REFERENCES `position` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `group` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`manager` int(11) NOT NULL,
`worker` int(11) NOT NULL,
PRIMARY KEY (`id`),
KEY `manager_id` (`manager`),
KEY `worker_id` (`worker`),
CONSTRAINT `group_ibfk_1` FOREIGN KEY (`manager`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT `group_ibfk_2` FOREIGN KEY (`worker`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `position` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`position` varchar(100) NOT NULL DEFAULT '',
PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `position` (`id`, `position`) VALUES
(1,'administration'),
(2,'manager'),
(3,'worker');

SET foreign_key_checks = 1;