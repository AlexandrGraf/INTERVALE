SET NAMES utf8;
SET foreign_key_checks = 0;

DROP DATABASE IF EXISTS `company`;
CREATE DATABASE `company` DEFAULT CHARACTER SET utf8;

USE `company`;

CREATE TABLE `employee` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`position` int(11) NOT NULL,
`first_name` varchar(100) NOT NULL DEFAULT '',
`last_name` varchar(100) NOT NULL DEFAULT '',
`middle_name` varchar(100) CHARACTER SET utf16 NOT NULL DEFAULT '',
`birth_date` date NOT NULL,
`hire_date` date NOT NULL,
`description` varchar(100) NOT NULL DEFAULT '',
PRIMARY KEY (`id`),
KEY `position` (`position`),
CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`position`) REFERENCES `position` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `employee` (`id`, `position`, `first_name`, `last_name`, `middle_name`, `birth_date`, `hire_date`, `description`) VALUES
(1,  1, 'Bo$$',       'BIG',      'Bigovich',   '1980-01-01', '2018-01-01', 'boss'),
(2,  1, 'MiddleBoss', 'Middle',   'Midlovich',  '1981-01-02', '2018-01-02', 'MiddleBoss'),
(3,  1, 'Blondy',     'Mistress', 'GirlFriday', '1982-01-03', '2018-01-03', 'Secretary'),
(4,  2, 'Manager1',   'Manager1', 'Manager1',   '1983-02-04', '2018-02-04', ''),
(5,  2, 'Manager2',   'Manager2', 'Manager2',   '1984-02-05', '2018-02-05', ''),
(6,  2, 'Manager3',   'Manager3', 'Manager3',   '1985-02-06', '2018-02-06', ''),
(7,  3, 'Worker1',    'Worker1',  'Worker1',    '1986-03-07', '2018-03-07', ''),
(8,  3, 'Worker2',    'Worker2',  'Worker2',    '1987-03-08', '2018-03-08', ''),
(9,  3, 'Worker3',    'Worker3',  'Worker3',    '1988-03-09', '2018-03-09', ''),
(10, 3, 'Worker4',    'Worker4',  'Worker4',    '1989-03-10', '2018-04-10', ''),
(11, 3, 'Worker5',    'Worker5',  'Worker5',    '1990-03-11', '2018-04-11', ''),
(12, 3, 'Worker6',    'Worker6',  'Worker6',    '1991-03-12', '2018-05-12', ''),
(13, 3, 'Worker7',    'Worker7',  'Worker7',    '1992-03-13', '2018-06-13', '');

CREATE TABLE `group` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`manager` int(11) NOT NULL,
`worker` int(11) NOT NULL,
PRIMARY KEY (`id`),
KEY `manager_id` (`manager`),
KEY `worker_id` (`worker`),
CONSTRAINT `group_ibfk_1` FOREIGN KEY (`manager`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT `group_ibfk_2` FOREIGN KEY (`worker`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `group` (`id`, `manager`, `worker`) VALUES
(1, 4, 7),
(2, 4, 8),
(3, 4, 9),
(4, 5, 10),
(5, 5, 11),
(6, 6, 12);

CREATE TABLE `position` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`position` varchar(100) NOT NULL DEFAULT '',
PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `position` (`id`, `position`) VALUES
(1, 'administration'),
(2, 'manager'),
(3, 'worker');