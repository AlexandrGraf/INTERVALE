package com.intervale.company.query;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

//@uthor Kravtsov A

public class MySQLQueries {

    private static final String QUERIES_FILE_PATH = "./src/com/intervale/company/files/query/queries.txt";

    public static Map<String, String> getQueries() {
        List<String> lines = getLines();
        Map<String, String> map = new TreeMap<>();
        for (String line : lines) {
            String[] array = line.split(":");
            map.put(array[0].trim(), array[1].trim());
        }
        return map;
    }

    private static List<String> getLines() {
        try {
            return Files.readAllLines(Paths.get(QUERIES_FILE_PATH));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
