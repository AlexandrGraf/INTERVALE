package com.intervale.company.query;

import com.intervale.company.model.Employee;
import com.intervale.company.model.Position;
import com.intervale.company.model.impl.Administration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//@uthor Kravtsov A

public class MySQLQuery {

    private final String PREFIX = "QUERY";
    private final String PREFIX_SELECT = "1";
    private final String PREFIX_INSERT = "2";
    private final String PREFIX_UPDATE = "3";
    private final String PREFIX_DELETE = "4";
    private final Map<String, String> QUERY_MAP = MySQLQueries.getQueries();

    public List<Employee> getAll(Connection connection) {
        String query = QUERY_MAP.get(PREFIX + PREFIX_SELECT + "01");
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            return getList(connection, rs);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Employee> getOne(Connection connection, int employeeId) {
        String query = QUERY_MAP.get(PREFIX + PREFIX_SELECT + "02");
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, employeeId);
            rs = ps.executeQuery();
            return getList(connection, rs);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean addOne(Connection connection, Administration administration) {
        String query = QUERY_MAP.get(PREFIX + PREFIX_INSERT + "01");
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, administration.getPosition().getId());
            ps.setString(2, administration.getFirstName());
            ps.setString(3, administration.getLastName());
            ps.setString(4, administration.getMiddleName());
            ps.setDate(5, administration.getBirthDate());
            ps.setDate(6, administration.getHireDate());
            ps.setString(7, administration.getDescription());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean changeOne(Connection connection, int id, int position) {
        return false;
    }

    public boolean removeOne(Connection connection, int id) {
        return false;
    }

    private List<Employee> getList(Connection connection, ResultSet resultSet) {
        try {
            List<Employee> employees = new ArrayList<>();
            while (resultSet.next()) {
                Administration administration = new Administration();
                administration.setId(resultSet.getInt(1));
                administration.setFirstName(resultSet.getString(3));
                administration.setLastName(resultSet.getString(4));
                administration.setMiddleName(resultSet.getString(5));
                administration.setBirthDate(resultSet.getDate(6));
                administration.setHireDate(resultSet.getDate(7));
                if (resultSet.getString(8).length() > 0) {
                    administration.setDescription(resultSet.getString(8));
                }
                int positionId = resultSet.getInt(2);
                Position position = getPosition(connection, positionId);
                administration.setPosition(position);
                employees.add(administration);
            }
            return employees;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Position getPosition(Connection connection, int positionId) {
        String query = QUERY_MAP.get(PREFIX + PREFIX_SELECT + "05");
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, positionId);
            rs = ps.executeQuery();
            rs.next();
            Position position = new Position();
            position.setId(rs.getInt(1));
            position.setPosition(rs.getString(2));
            return position;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
