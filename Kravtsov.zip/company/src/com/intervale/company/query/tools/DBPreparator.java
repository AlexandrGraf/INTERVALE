package com.intervale.company.query.tools;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

//@uthor Kravtsov A

public class DBPreparator {

    private static final String DATABASE = "./src/com/intervale/company/files/sql/database.sql";
    private static final String SANDBOX = "./src/com/intervale/company/files/sql/sandbox.sql";

    public static void createDatabase(Connection connection) {
        List<String> queries = ScriptReader.reader(DATABASE);
        sendQueries(connection, queries);
    }

    public static void createSandbox(Connection connection) {
        List<String> queries = ScriptReader.reader(SANDBOX);
        sendQueries(connection, queries);
    }

    private static void sendQueries(Connection connection, List<String> queries) {
        for (String query : queries) {
            executeQuery(connection, query);
        }
    }

    private static void executeQuery(Connection connection, String query) {
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(query);
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
