package com.intervale.company.query.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//@uthor Kravtsov A

public class ScriptReader {

    public static List<String> reader(String filePath) {

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            List<String> lines = new ArrayList<>();
            String line;
            StringBuilder query = new StringBuilder();
            while((line = br.readLine()) != null) {
                if (line.endsWith(";")) {
                    query.append(line);
                    lines.add(query.toString());
                    query.setLength(0);
                } else {
                    query.append(line);
                }
            }
            return lines;
        } catch(IOException e){
            e.printStackTrace();
            return null;
        }
    }
}