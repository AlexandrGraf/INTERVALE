package com.intervale.company;

import com.intervale.company.connector.MySQLConnector;
import com.intervale.company.counting.CountingSystem;
import com.intervale.company.model.Employee;

//@uthor Kravtsov A

import java.sql.Connection;

public class Main {

    public static void main(String[] args) {

        Connection connection = MySQLConnector.getConnection();
        CountingSystem countingSystem = new CountingSystem();
        countingSystem.getMainMenu(connection);
    }
}
